import React from "react";
import "./LeftSide.css";

class LeftSide extends React.Component {
  render() {
    return (
      <div className='LeftSide'>
        <ul>
          <li>
            <img
              src='https://simply-communicate.com/wp-content/uploads/2019/03/facebook-2661207_960_720.jpg'
              alt=''
            ></img>
          </li>

          <li>
            <img
              src='https://assets.materialup.com/uploads/82eae29e-33b7-4ff7-be10-df432402b2b6/preview'
              alt=''
            ></img>
          </li>
        </ul>
      </div>
    );
  }
}

export default LeftSide;
