import React from "react";
import "./RightSide.css";

class RightSide extends React.Component {
  render() {
    return (
      <div className='RightSide'>
        <ul>
          <li>EREN</li>
          <li>SEYMA</li>
          <li>MERIC</li>
          <li>BAHRIYE</li>
          <li>RIFAT</li>
          <li>BETUS</li>
        </ul>
      </div>
    );
  }
}

export default RightSide;
